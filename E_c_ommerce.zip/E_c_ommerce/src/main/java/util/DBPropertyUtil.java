package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBPropertyUtil {

    public static String getConnectionUrl() {
        String hostname = "localhost";
        String port = "3306";
        String dbname = "ecommerce_db";          // Replace with your DB name
        String username = "root";          // Replace with your DB username
        String password = "Hexaware@12345";  // Replace with your DB password

        return "jdbc:mysql://" + hostname + ":" + port + "/" + dbname +
                "?user=" + username + "&password=" + password;
    }

    public static Connection getConnection() throws SQLException {
        String url = getConnectionUrl();
        return DriverManager.getConnection(url);
    }
}
