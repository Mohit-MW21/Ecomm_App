package dao;

import entity.Customer;
import entity.Order;
import entity.OrderItem;
import entity.Product;
import exception.CustomerNotFoundException;
import exception.OrderNotFoundException;
import exception.ProductNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface OrderProcessorRepository {
    // Customer Management
    boolean createCustomer(Customer customer) throws SQLException;
    boolean deleteCustomer(int customerId) throws SQLException, CustomerNotFoundException;
    
    // Product Management
    boolean createProduct(Product product) throws SQLException;
    boolean deleteProduct(int productId) throws SQLException, ProductNotFoundException;
    
    // Cart Management
    boolean addToCart(Customer customer, Product product, int quantity) 
        throws SQLException, CustomerNotFoundException, ProductNotFoundException;
    boolean removeFromCart(Customer customer, Product product) 
        throws SQLException, CustomerNotFoundException, ProductNotFoundException;
    List<Product> getAllFromCart(Customer customer) 
        throws SQLException, CustomerNotFoundException;
    
    // Order Management
    boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsWithQuantities, String shippingAddress) 
        throws SQLException, CustomerNotFoundException, ProductNotFoundException;
    List<Map<Product, Integer>> getOrdersByCustomer(int customerId) 
        throws SQLException, CustomerNotFoundException, OrderNotFoundException;
    Order getOrderById(int orderId) throws SQLException, OrderNotFoundException;
    List<OrderItem> getOrderItemsByOrderId(int orderId) throws SQLException, OrderNotFoundException;
    boolean cancelOrder(int orderId) throws SQLException, OrderNotFoundException;
    
    // Utility method (for implementation use)
    Connection getConnection();
}